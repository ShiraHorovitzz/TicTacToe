//Tehila Menasheof 206089195
//Shira Horovitz 302642665
public enum PlayerType {
	FREE, X, O

}

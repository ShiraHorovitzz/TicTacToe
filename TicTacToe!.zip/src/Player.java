//Tehila Menasheof 206089195
//Shira Horovitz 302642665
public abstract class Player {
	PlayerType p;
	Game g;
	
	public Player() {
		this.p=PlayerType.X;
	}
}

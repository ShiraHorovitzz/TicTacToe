//Tehila Menasheof 206089195
//Shira Horovitz 302642665
public class CellCoordinates {

	final private int col_;
	final private int row_;

	public int getCol() {
		return col_;
	}

	public int getRow() {
		return row_;
	}

	public CellCoordinates(int row, int col) {
		col_ = col;
		row_ = row;
	}

}
